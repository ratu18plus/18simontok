<?php
$emailku = 'nitcizx06@gmail.com'; // GANTI EMAIL KAMU DISINI
?>