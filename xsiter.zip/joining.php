<?php 
$link_grup = $_POST['link_grup'];
?>
<html>
<head>
<meta http-equiv="REFRESH" content="0;url=<?php echo $link_grup;?>">
</head>
<body>
</body>
</html>